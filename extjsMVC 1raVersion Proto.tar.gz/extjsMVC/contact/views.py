# -*- coding: utf-8 -*-

from django.db import transaction
from django.http import HttpResponse
from django.template import RequestContext
from django.forms.models import model_to_dict
from django.shortcuts import render_to_response, get_object_or_404
from django.utils.translation import gettext as __
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from models import Contact

from django.core import serializers
import simplejson as json

def view(request):
    page = int(request.GET.get('page', 0))
    start = int(request.GET.get('start', 0))
    limit = int(request.GET.get('limit', 0))
    total_contacts = Contact.objects.all().count()
    contacts = Contact.objects.all()[start:limit*page]
    list = []
    for contact in contacts:
        list.append(model_to_dict(contact, fields=[field.name for field in contact._meta.fields]))
        
    context = {
        'total': total_contacts,
        'data': list,
        'success': True
        
    }
    
    return HttpResponse(json.dumps(context), mimetype="application/json")


def existContact( key ):
    try:
        contact = Contact.objects.get( name = key  )
        return True 
    except:
        return False  


def create(request):
    
    list = []
    success = True
    message = '' 

    if not request.POST:
        return 
    
    dataList = json.loads(request.POST.keys()[0])['data']
    if type(dataList).__name__=='dict':
        dataList = [dataList]
        
    for data in dataList: 

        if  existContact( data['name'] ):
            success = False
            message = 'Este registro ya existe'
        else:  
    
            contact = Contact()
            contact.name = data['name']
            contact.phone = data['phone']
            contact.email = data['email'] 
            
            if not contact.email.__contains__('@'):
                contact.email += '@123.aa'
    
            try:
        contact.save()
                contactReg = model_to_dict(contact, fields=[field.name for field in contact._meta.fields])
                list.append( contactReg )
                
            except: 
                success = False
                message = 'Error al crear registro'
                
                
        
    context = {
        'total': list.__len__(),
        'data': list,
        'success': success, 
        'message' : message 
    }
    return HttpResponse(json.dumps(context), mimetype="application/json")

def update(request):
    
    list = []
    success = True
    message = '' 

    if not request.POST:
        return 
    
    dataList = json.loads(request.POST.keys()[0])['data']
    if type(dataList).__name__=='dict':
        dataList = [dataList]

    for data in dataList: 

        try:
            contact = Contact.objects.get( pk = data['id']  )
    
            contact.name = data['name']
            contact.email = data['email']
            contact.phone = data['phone']

            try:
    contact.save()
    list.append(model_to_dict(contact, fields=[field.name for field in contact._meta.fields]))
            except: 
                success = False
                message = 'Error al actualizar registro'

        except:
            success = False
            message = 'Registro no encontrado' 


    context = {
        'total': list.__len__(),
        'data': list,
        'success': success, 
        'message' : message 
    }
    return HttpResponse(json.dumps(context), mimetype="application/json")

def delete(request):

    success = True
    message = '' 

    if not request.POST:
        return 
    
    dataList = json.loads(request.POST.keys()[0])['data']
    if type(dataList).__name__=='dict':
        dataList = [dataList]

    for data in dataList: 
        try:
            contact = Contact.objects.get( pk = data['id']  )

            try:
    contact.delete()
            except: 
                success = False
                message = 'Error al borrar registro'

        except:
            success = False
            message = 'Registro no encontrado' 

    context = {
        'success': success, 
        'message' : message 
    }
    return HttpResponse(json.dumps(context), mimetype="application/json")



def menu(request):
    context = [{
                    'text':'Dictionaire de donnes',
                    'expanded':True,
                    'children':[
                        { 'id': 'Concept' , 'text':'Elements des donnes', 'leaf':True },
                        { 'id': 'Property' , 'text':'Proprietes',  'leaf':True },
                    ]
                }]

    return HttpResponse(json.dumps(context), mimetype="application/json")

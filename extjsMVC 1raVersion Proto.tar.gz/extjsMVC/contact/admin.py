from contact.models import Contact
from django.contrib import admin

admin.site.register(Contact)

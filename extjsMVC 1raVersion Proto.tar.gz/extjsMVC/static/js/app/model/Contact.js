// ['id', 'name', 'phone', 'email'] 
Ext.define('ProtoUL.model.Contact', {
    extend: 'Ext.data.Model',

    // 1. Definicion estandar  
    fields: ['id', 'name', 'phone', 'email'],

    
});
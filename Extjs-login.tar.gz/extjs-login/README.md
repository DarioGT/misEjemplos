django-extjs-login
=====================

created by [gary][5] and [julien][6] @revolunet and hosted at [GitHub][4]

this an ExtJs login Widget with a django backend

**Features** :

 - ExtJs login widget
 - password reset via email
 - password change view


**Requirements :** 

  - [django-skeleton][1]
  - [django-extjs][2]

 


  [1]: http://github.com/revolunet/django-skeleton
  [2]: http://github.com/revolunet/django-extjs
  [4]: https://github.com/revolunet/django-extjs-login
  [5]: mailto:gary@chewam.com
  [6]: mailto:julien@bouquillon.com
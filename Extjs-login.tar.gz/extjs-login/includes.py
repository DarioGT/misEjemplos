# here needed JS and CSS

JS = [
  'Ext.ux.EasyChangePass.js',
  'Ext.ux.EasyLogin.js',

]

CSS = [

]

